namespace ScreenToGif.ViewModel.UploadPresets.Custom;

public class CustomPreset : UploadPreset
{
    //Custom uploader.
    //List of calls, with address, input and output.
    //Data flow.
}