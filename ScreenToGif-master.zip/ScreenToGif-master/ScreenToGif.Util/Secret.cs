namespace ScreenToGif.Util;

public static class Secret
{
    public static string ServerAddress => "";

    public static string Email => "";

    public static string Password => "";

    public static int Port => 0;

    public static string Host => "";


    public static string ImgurId => "";

    public static string ImgurSecret => "";

    public static string GfycatId => "";

    public static string GfycatSecret => "";

    public static string YandexId => "";
}