namespace ScreenToGif.Util.Codification.Psd.AdditionalLayers;

interface IAdditionalLayerInfo : IPsdContent
{
    string Key { get; }
}