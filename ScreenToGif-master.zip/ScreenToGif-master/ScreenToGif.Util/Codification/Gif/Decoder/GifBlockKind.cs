namespace ScreenToGif.Util.Codification.Gif.Decoder;

public enum GifBlockKind
{
    Control,
    GraphicRendering,
    SpecialPurpose,
    Other
}