namespace ScreenToGif.Domain.Interfaces
{
    public interface IPersistent
    {
        void Persist();
    }
}