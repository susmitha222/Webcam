namespace ScreenToGif.Domain.Enums;

public enum MouseButtons
{
    None,
    Left,
    Middle,
    Right
}