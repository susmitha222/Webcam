namespace ScreenToGif.Domain.Enums;

/// <summary>
/// Specifies the frame removal mode.
/// </summary>
public enum DuplicatesRemovalModes
{
    First = 0,
    Last = 1
}