namespace ScreenToGif.Domain.Enums;

public enum EncoderTypes
{
    ScreenToGif, //Gif, Apng
    KGySoft, // Gif
    System, //Gif, Video
    FFmpeg, //Gif, Webp, Apng, Video
    Gifski //Gif
}