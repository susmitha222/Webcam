namespace ScreenToGif.Domain.Enums;

public enum AppThemes
{
    Light,
    Medium,
    Dark,
    VeryDark,
    FollowSystem
}