namespace ScreenToGif.Domain.Enums;

public enum Vsyncs
{
    Off,
    Auto,
    Passthrough,
    Cfr,
    Vfr,
    Drop
}