namespace ScreenToGif.Domain.Enums;

public enum SizeUnits
{
    Pixels,
    Percent
}