namespace ScreenToGif.Domain.Enums;

/// <summary>
/// Type of the progress indicator.
/// </summary>
public enum ProgressTypes
{
    Bar,
    Text
}