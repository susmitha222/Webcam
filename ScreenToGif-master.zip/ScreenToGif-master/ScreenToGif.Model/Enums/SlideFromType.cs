namespace ScreenToGif.Domain.Enums;

/// <summary>
/// Transition animation.
/// </summary>
public enum SlideFromType
{
    Right,
    Top,
    Left,
    Bottom
}