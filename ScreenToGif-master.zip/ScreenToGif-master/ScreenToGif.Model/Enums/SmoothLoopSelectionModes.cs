namespace ScreenToGif.Domain.Enums;

public enum SmoothLoopFromModes
{
    End = 0,
    Start = 1
}