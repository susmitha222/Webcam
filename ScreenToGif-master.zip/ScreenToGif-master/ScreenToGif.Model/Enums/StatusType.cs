namespace ScreenToGif.Domain.Enums;

public enum StatusType : int
{
    None = 0,
    Info,
    Update,
    Warning,
    Error
}