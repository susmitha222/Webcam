namespace ScreenToGif.Domain.Enums;

public enum VideoSettingsModes
{
    Normal,
    Advanced
}