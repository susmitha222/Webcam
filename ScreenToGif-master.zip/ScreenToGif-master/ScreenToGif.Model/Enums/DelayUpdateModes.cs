namespace ScreenToGif.Domain.Enums;

public enum DelayUpdateModes
{
    Override = 0,
    IncreaseDecrease = 1,
    Scale = 2
}