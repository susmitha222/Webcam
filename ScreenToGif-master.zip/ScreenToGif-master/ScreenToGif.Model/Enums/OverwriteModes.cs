namespace ScreenToGif.Domain.Enums;

public enum OverwriteModes
{
    Allow,
    Warn,
    Prompt
}