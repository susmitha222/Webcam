namespace ScreenToGif.Domain.Enums.Native;

public enum DibColorModes : uint
{
    RgbColors = 0,
    PalColors = 1
}