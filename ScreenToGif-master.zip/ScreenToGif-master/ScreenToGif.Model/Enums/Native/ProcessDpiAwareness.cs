namespace ScreenToGif.Domain.Enums.Native;

public enum ProcessDpiAwareness
{
    ProcessDpiUnaware = 0,
    ProcessSystemDpiAware = 1,
    ProcessPerMonitorDpiAware = 2
}