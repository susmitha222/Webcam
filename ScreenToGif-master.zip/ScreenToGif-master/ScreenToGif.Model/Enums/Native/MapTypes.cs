namespace ScreenToGif.Domain.Enums.Native;

public enum MapTypes : uint
{
    MapvkVkToVsc = 0x0,
    MapvkVscToVk = 0x1,
    MapvkVkToChar = 0x2,
    MapvkVscToVkEx = 0x3,
}