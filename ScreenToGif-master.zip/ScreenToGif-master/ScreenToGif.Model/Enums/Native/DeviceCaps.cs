namespace ScreenToGif.Domain.Enums.Native;

public enum DeviceCaps : int
{
    LogPixelsX = 88,
    LogPixelsY = 90,
}