namespace ScreenToGif.Domain.Enums.Native;

public enum TimerResults : uint
{
    NoError = 0,
    NoCanDo = 97
}