namespace ScreenToGif.Domain.Enums;

public enum ObfuscationModes
{
    Pixelation,
    Blur,
    Darken,
    Lighten
}