namespace ScreenToGif.Domain.Enums;

public enum Framerates
{
    Auto,
    Custom,
    Film,
    Ntsc,
    Pal
}